<template>
    <div>
        <iv-visualisation :title="projectName">
            <h3 style="margin-left:5vh;">FRF and Time history plot of your desired forcing frequency</h3>
            <h4 style="margin-left:5vh;">Please choose a excitation frequency using the slider below</h4>
            
            <div style="margin:5vh;" id="flexContainer">
                <div id="innerFlex1">
                    <iv-slider name="Excitation Frequency (Hz):"  ref="wSlider" min=0 :max=wlim init_val=1 @sliderChanged="updateSlider" :value=wSlider></iv-slider>
                    <div id='graph'></div>
                </div>
                <div id="innerFlex2">
                    <br><br><br><br>
                    <div id='graph2' ></div>
                </div> 
            </div>

            <div style="margin:5vh;"> 

                <div style="margin:20px;" v-show="wdHz">
                    <br><br>
                    <strong>System Parameters:</strong>
                    <br>
                    Natural Frequency, ω<sub>n</sub> (rad/s): {{ wn }} rad/s
                    <br>
                    Natural Frequency, ω<sub>n</sub> (Hz): {{ wnHz }} Hz
                    <br>
                    Damped Natural Frequency, ω<sub>d</sub> (rad/s): {{ wd }} rad/s 
                    <br>
                    Damped Natural Frequency, ω<sub>d</sub> (Hz): {{ wdHz }} Hz
                </div>

                <div style="margin:20px;" v-show="!wdHz">
                    <br><br>
                    <strong>System Parameters:</strong>
                    <br>
                    Natural Frequency, ω<sub>n</sub> (rad/s): {{ wn }} rad/s
                    <br>
                    Natural Frequency, ω<sub>n</sub> (Hz): {{ wnHz }} Hz
                </div>
            </div>

            <template #hotspots>
                <iv-pane position="left" @paneResize="update" @paneToggle="update">
                    <iv-sidebar-content>
                        <iv-sidebar-section title="Forced Vibrations">
                            <img src="./assets/ForcedVib.png" style="width:13vw;">
                            <br>
                            This Forced Vibrations solver takes in your parameters and then produces an FRF response. You can then choose a frequency to view the time history plot at that specific frequency.
                            Try it out by changing the input parameters. To submit feedback for this module please click,
                            <a href="https://forms.gle/W4DmoEKuGnu2RkWN6" target="_blank">here.</a>                  
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                <iv-pane position="right" :allowResize=false>
                    <div style="margin-top:0px; padding:20px;" >
                        <h5>System Parameters</h5>
                        <label>Mass, m (kg)</label>
                        <br>
                        <input v-model="mass" @change="update">
                        <br>
                        <label>Spring Constant, k (N/m)</label>
                        <br>
                        <input v-model="springConst"  @change="update">
                        <br>
                        <label>Use Damping Coefficient</label>
                        <br>
                        <iv-toggle-basic @input="dampToggle"></iv-toggle-basic>
                        <label v-show="!showCoeff" >Damping Ratio, ζ</label>
                        <br>
                        <input v-model="dampRatio"  @change="updateDampRatio" v-show="!showCoeff">
                        <label v-show="showCoeff">Damping Coefficient, c (Ns/m)</label>
                        <br>
                        <input v-model="dampCoeff"  @change="updateDampCoeff"  v-show="showCoeff">

                        <h5>Initial Conditions</h5>
                        <label>Initial Displacement, X0 (m)</label>
                        <br>
                        <input v-model="initDisp"  @change="update">
                        <br>

                        <label>Forcing Amplitude, F<sub>0</sub> (N)</label>
                        <br>
                        <input v-model="forceAmp"  @change="update">
                        
                        <h5>Computational Parameters</h5>
                        <label>ω Axis Limit, ω (Hz)</label>
                        <br>
                        <input v-model="wlim"  @change="update">
                        <br>
                        <label>Time Scale, t (s)</label>
                        <br>
                        <input v-model="timeSpan"  @change="update">
                        <br>

                        <br>
                    </div>
                </iv-pane>
                
                <!-- <iv-fixed-hotspot position="topright" style="width:300px; z-index:2" transparent>
                    
                </iv-fixed-hotspot> -->
            </template>

        
        </iv-visualisation>
    </div>
</template>
<script>
import Plotly from 'plotly.js/dist/plotly.min.js'; // eslint-disable-line no-unused-vars

export default {
    name:"App",
    data(){
        return {
            projectName: 'Vibrations App - Forced Vibrations',
            mass: 1,
            dampRatio: 0.1,
            initDisp:0.1,
            timeSpan:2,
            springConst: 1000,
            dampCoeff:6.325,
            numPoints:1000,
            wlim: 20,
            wSlider: 1,
            updatePlot: true,
            wn: 32,
            wnHz: 5,
            wd: 31,
            wdHz: 5,
            forceAmp: 5,
            maxAmp: 0.1,
            showText: true,
            showCoeff: false,
        }
    },
    methods: {
        update(){
            if(this.mass <= 0){
                window.alert("Mass must be greater than 0.");
                this.mass = 1;
            }
            if(this.springConst <= 0){
                window.alert("Spring constant must be greater than 0.");
                this.springConst = 1000;
            }
            if(this.timeSpan <= 0){
                window.alert("Time span must be greater than 0.");
                this.springConst = 1000;
            }
            if(this.numPoints <= (2*this.wnHz * this.timeSpan)){
                window.alert(`Please ensure your sampling frequency (Number of Points/Time Span), ${this.numPoints/this.timeSpan} Hz, is well above double the natural frequency of the system, ${this.wnHz} Hz. This is to prevent aliasing from occuring. We recommend increasing the number of points beyond ${4*this.wnHz * this.timeSpan} points.`);
                this.numPoints = (4*this.wnHz * this.timeSpan);
            }
            if(this.wSlider > this.wlim){
                this.$refs.wSlider.reset();
            }
            if(this.wlim < 0.1){
                window.alert("Omega limit must be greater 0.1 Hz.");
                this.wlim = 0.1;
            }

            console.log('update');

            this.updatePlot = true;
        },
        updateSlider(e){
            this.wSlider = e;
            this.updatePlot = true;
        },
        updateDampCoeff(){
            if(this.dampCoeff < 0){
                window.alert("Damping coefficient must be greater than 0.");
                this.dampCoeff = 6.325;
            }
            this.dampRatio = Math.round( (this.dampCoeff / (2*Math.sqrt(this.springConst * this.mass))) *1000 )/1000;
            this.updatePlot = true;
        },
        updateDampRatio(){
            if(this.dampRatio < 0 || this.dampRatio > 2){
                window.alert("Damping ratio must be greater than 0 and less than or equal to 2.");
                this.dampRatio = 0.1;
            }
            this.dampCoeff = Math.round( (this.dampRatio *2 * Math.sqrt(this.springConst * this.mass) )*1000)/1000;
            this.updatePlot = true;
        },
        dampToggle(){
            this.showCoeff = !this.showCoeff;
        },
    },
    mounted(){
        let vm = this; // eslint-disable-line no-unused-vars

        let layout = {
            xaxis: {title:"Time (sec)"},
          yaxis: {
            title:"Displacement Response (m)",
          },
          yaxis2: {
            title:"Force Amplitude (m)",
            overlaying: 'y',
            side: 'right',
          },
          font: {
                color: "#003E74",
                weight: 900
          }
        };

        let config = {responsive: true};

        function FRF_Solver(){

            let m = vm.mass;
            let k = vm.springConst;
            let dampRatio = Number(vm.dampRatio);
            let c = vm.dampCoeff;
            let wAxisLimit = vm.wlim;
            let wHz_axis = [];
            let amp = [];
            let phase = [];

            c = dampRatio * 2 * Math.sqrt(k * m)

            for(let i = 0; i < wAxisLimit; i = i + wAxisLimit/1000){
                wHz_axis.push(i);
                amp.push(1 / Math.sqrt((k - m * (2 * Math.PI * i) ** 2) ** 2 + (c * 2 * Math.PI * i) ** 2));
                phase.push((Math.atan2(-c * (2 * Math.PI * i), (k - m * (2 * Math.PI * i) ** 2)))*180/Math.PI);
            }

            return [wHz_axis, amp, phase]
        }

        function forcedSolver(){
            
            let m = vm.mass;
            let k = vm.springConst;
            let dampRatio = Number(vm.dampRatio);
            let x0 = vm.initDisp;
            let Famp = vm.forceAmp;
            let wHz = vm.wSlider;
            let c = vm.dampCoeff;
            let w = 2 * Math.PI * wHz;
            let x = [];
            let t = [];
            let F = [];

            let wn = Math.sqrt(k / m);  // Natural Freq of spring mass system
            let wnHz = wn/(2*Math.PI);    // Natural freq in Hz
            let wd, wdHz;
            if (0 < dampRatio && dampRatio < 1){
                 wd = wn*Math.sqrt(1 - dampRatio**2);    // Damped nat freq (rad/s)
                 wdHz = wd/(2*Math.PI);     // Damped Natural freq in Hz
            } else{
                wd = 0;
                wdHz = 0;
            }
            

            // Work out Nice time frame using decay to 10%
            // let t_decay = 1 / (dampRatio * wn) * Math.log(1 / 0.01);
            // let tend = t_decay * 1.25;
            let tend = vm.timeSpan;

            
            // Solving for Complete Forced Solution
            // Displacement amplitude from force ONLY
            let x0f = Famp / Math.sqrt((k - m * w ** 2) ** 2 + (c * w) ** 2);
            let phasef = Math.atan(c * w / (k - m * w ** 2));

            let A = x0 - x0f * Math.sin(-phasef);
            let B;
            if (0 < dampRatio  && dampRatio < 1){
                B = (dampRatio * wn * A - x0f * w * Math.cos(-phasef)) / wd;
            }else{
                B = 0;
            }

            for(let i = 0; i < tend; i = i + tend/10000){
                t.push(i);
                x.push(Math.exp(-dampRatio * wn * i) * (A * Math.cos(wd * i) + B * Math.sin(wd * i)) + x0f * Math.sin(w * i - phasef));
                F.push(Famp * Math.sin(w * i));
                
            }

            let max = x.reduce(function(a,b) {
                return Math.max(a,b)
            });
            vm.maxAmp = Math.round(max*100)/100;
            vm.wn = Math.round(wn*100)/100;
            vm.wnHz = Math.round(wnHz*100)/100;
            vm.wd =  Math.round(wd * 100)/100;
            vm.wdHz = Math.round(wdHz * 100)/100;    

            return [x, t, F]
        }

        function update(){
            requestAnimationFrame(update);

            if(vm.updatePlot ){
                vm.updatePlot = false;
                
                let data = forcedSolver();
                let data2 = FRF_Solver();

                let max1 = data2[1].reduce(function(a,b) {
                    return Math.max(a,b)
                });
                let min1 = data2[1].reduce(function(a,b) {
                    return Math.min(a,b)
                });

                // Redefine layout to keep axes ranges the same
                layout = {
                    xaxis: {title:"Time (sec)"},
                yaxis: {
                    title:"Displacement Response (m)",
                    range: [-1.1 * vm.maxAmp, 1.1 * vm.maxAmp],
                },
                yaxis2: {
                    title:"Force Amplitude (m)",
                    overlaying: 'y',
                    side: 'right',
                    range: [-1.1 * vm.forceAmp, 1.1 * vm.forceAmp],
                    showgrid: false,
                },
                font: {
                        color: "#003E74",
                        weight: 900
                },
                legend: {
                    bgcolor: 'rgba(0,0,0,0.2)',
                    x: 1,
                    xanchor: 'right',
                    y: 1.2
                }
                };

                let layout2 = {
                    xaxis: {title:"Excitation frequency (Hz)"},
                yaxis: {
                    title:"x/F (m/N)",
                },
                yaxis2: {
                    title:"Phase (Degrees)",
                    overlaying: 'y',
                    side: 'right',
                    showgrid: false,
                },
                font: {
                        color: "#003E74",
                        weight: 900
                },
                legend: {
                    bgcolor: 'rgba(0,0,0,0.2)',
                    x: 1,
                    xanchor: 'right',
                    y: 1.2,
                }
                };

                Plotly.newPlot('graph', [{
                    x: data2[0],
                    y: data2[1],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "FRF Amplitude"
                },
                {
                    x: data2[0],
                    y: data2[2],
                    line: {simplify: false},
                    mode: 'lines',
                    name: "FRF Phase", 
                    yaxis: 'y2'
                },
                {
                    x: [vm.wSlider, vm.wSlider],
                    y: [min1, max1],
                    mode: 'lines',
                    showlegend: false,
                    line: {
                        dash: 'dashdot',
                        color: 'red'
                    }

                }],
                layout2,
                config
                )
                
                Plotly.newPlot('graph2', [
                {
                x : data[1],
                y : data[0],
                line: {simplify: false},
                mode: 'lines',
                name: "Displacement Response, x"
                },
                {
                x : data[1],
                y : data[2],
                line: {simplify: false},
                mode: 'lines',
                name: "Force, F",
                yaxis: 'y2'
                }
                ],
                layout,
                config
                )
                
                
            }

        }

        update();
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
html{
    overflow: hidden;
}
.iv-pane-right{
    overflow: auto;
}
#graph {
    z-index:-2;
}
@media screen and (orientation: portrait) {
    #innerFlex1 {
        width:20vw;
        min-width: 300px;
        flex-grow: 1;
    }
    #innerFlex2 {
        width: 30vw;
        min-width: 300px;
        flex-grow: 1;
    }
    #flexContainer {
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;

    }
}

@media screen and (orientation: landscape) {
    /* #graph {
        width:25vw; height:400px;
    }
    #graph2 {
        width:25vw; height: 400px;
    } */
    #innerFlex1 {
        width:40%;
        min-width: 300px;
        flex-grow: 1;
    }
    #innerFlex2 {
        width: 50%;
        min-width: 300px;
        flex-grow: 2;
    }
    #flexContainer {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;

    }
}
</style>